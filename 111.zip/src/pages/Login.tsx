import {
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardSubtitle,
    IonCardTitle,
    IonContent,
    IonHeader,
    IonIcon,
    IonItem,
    IonLabel,
    IonList,
    IonListHeader,
    IonPage,
    IonTitle,
    IonToolbar,
    IonInput,
    IonButton,
    IonGrid,
    IonRow,
    IonCol
} from '@ionic/react';
import { book, build, colorFill, grid } from 'ionicons/icons';
import React from 'react';
import './LoginPage.css';

const LoginPage: React.FC = () => {
    return (
        <IonPage  >
            <IonHeader>
                <IonToolbar color="primary">
                    <IonTitle slot="start" align-self-center="">AP Police</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen >
                <IonGrid className="content-background">
                    <IonRow className="ion-justify-content-center">
                        <IonCol sizeXs="0" size="3" sizeLg="3"></IonCol>
                        <IonCol size="6" sizeLg="6" sizeXs="12">
                            <div className="ion-text-center">
                                <img src="/assets/police_icon.jpg" alt="" />
                            </div>
                            <IonItem>
                                <IonLabel position="floating">User Name</IonLabel>
                                <IonInput></IonInput>
                                <IonIcon align-self-end="" name="person" slot="start" />
                            </IonItem>

                            <IonItem>
                                <IonLabel position="floating">Password</IonLabel>
                                <IonIcon align-self-end="" name="lock" slot="start" />

                                <IonInput type="password"></IonInput>
                            </IonItem>
                            <div className="ion-padding">
                                <IonButton color="light" expand="block" type="submit" className="ion-no-margin">Login</IonButton>
                            </div>
                            <div className="ion-padding">
                                <IonButton color="light" expand="block" type="submit" className="ion-no-margin">Sign up</IonButton>
                            </div>
                        </IonCol>
                        <IonCol sizeXs="0" sizeLg="3" size="3"></IonCol>
                    </IonRow>
                </IonGrid>
            </IonContent>
        </IonPage>
    );
};

export default LoginPage;
